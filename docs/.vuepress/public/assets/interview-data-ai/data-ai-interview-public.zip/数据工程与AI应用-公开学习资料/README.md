# 数据工程与AI应用｜公开学习资料

作者：布衣云水客。此目录仅包含公开教学内容和合成练习数据，不含个人简历或客户内部材料。

先读完整学习手册.html，再按08章计划复习。编号保留知识主题分类：02 SQL、03建模、04分析/Python、05服务设计、06 AI、08学习计划、09实操。

运行需要Python 3.9+和SQLite 3.25+，不需要第三方库：

```bash
python3 练习/sql_lab.py
python3 练习/analysis_lab.py
python3 练习/ai_eval_lab.py
```

如本机python3指向旧版，请改用python3.12等合适解释器。三个脚本已在Python 3.12环境运行通过。AI评测脚本仅演示人工标签和预测，不连接真实模型。

原文：https://blog.chcbz.net/article/2026/202609211100.html

官方参考入口未逐页实时核验，特定技术行为以实际产品版本文档为准。
