#!/usr/bin/env python3
"""标准库金额分析，对照SQL；先运行sql_lab.py。"""
import csv
import json
from collections import defaultdict
from datetime import datetime
from decimal import Decimal
from pathlib import Path

OUT=Path(__file__).resolve().parent/'output'

def read(name):
    with (OUT/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def unique(rows,key):
    vals=[r[key] for r in rows]
    assert all(vals) and len(set(vals))==len(vals), 'duplicate/missing '+key

def main():
    orders,refunds=read('orders.csv'),read('refunds.csv')
    unique(orders,'order_id'); unique(refunds,'refund_id')
    ids={r['order_id'] for r in orders}
    rsum=defaultdict(int)
    for r in refunds:
        assert r['order_id'] in ids, 'orphan refund'
        assert int(r['refund_cents'])>=0
        rsum[r['order_id']]+=int(r['refund_cents'])
    monthly={(r,m):0 for r in ['east','west'] for m in ['2026-01','2026-02','2026-03']}
    paid_count=0
    for o in orders:
        datetime.strptime(o['order_date'],'%Y-%m-%d')
        assert o['region'] in ('east','west')
        assert o['status'] in ('paid','cancelled')
        amount=int(o['amount_cents'])
        assert amount>=0
        assert 0<=rsum[o['order_id']]<=amount, 'over-refund: investigate, do not silently discard'
        if o['status']=='paid':
            key=(o['region'],o['order_date'][:7])
            assert key in monthly
            monthly[key]+=amount-rsum[o['order_id']]
            paid_count+=1
    expected=json.loads((OUT/'monthly_sql.json').read_text(encoding='utf-8'))
    assert monthly=={(r['region'],r['month']):r['net_cents'] for r in expected}
    total=sum(monthly.values())
    assert total==70000 and paid_count==5
    report={
        'data':'synthetic, single currency; refund assigned to order month',
        'data_complete_assumption':True,
        'net_amount':str(Decimal(total)/100),
        'paid_order_count':paid_count,
        'avg_net_per_paid_order':str((Decimal(total)/100/paid_count).quantize(Decimal('0.01'))),
        'quality':'PASS: keys, references, dates, domains, integer amounts, refund bounds, SQL parity',
        'monthly':[{'region':r,'month':m,'net_amount':str(Decimal(v)/100)} for (r,m),v in sorted(monthly.items())]
    }
    assert report['avg_net_per_paid_order']=='140.00'
    (OUT/'analysis_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('ANALYSIS PASS: SQL parity, total=700.00, paid orders=5, average=140.00')

if __name__=='__main__':
    main()
