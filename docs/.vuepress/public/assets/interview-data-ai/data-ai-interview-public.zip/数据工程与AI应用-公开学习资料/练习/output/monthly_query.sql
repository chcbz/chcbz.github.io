
WITH months(month) AS (VALUES ('2026-01'),('2026-02'),('2026-03')),
regions(region) AS (VALUES ('east'),('west')),
r AS (SELECT order_id, SUM(refund_cents) AS refund FROM refunds GROUP BY order_id),
a AS (
 SELECT o.region, substr(o.order_date,1,7) AS month,
        SUM(o.amount_cents-COALESCE(r.refund,0)) AS net_cents
 FROM orders o LEFT JOIN r ON o.order_id=r.order_id
 WHERE o.status='paid' AND o.order_date>='2026-01-01' AND o.order_date<'2026-04-01'
 GROUP BY o.region, substr(o.order_date,1,7)
),
skeleton AS (
 SELECT regions.region,months.month,COALESCE(a.net_cents,0) AS net_cents
 FROM regions CROSS JOIN months
 LEFT JOIN a ON a.region=regions.region AND a.month=months.month
), lagged AS (
 SELECT *, LAG(net_cents) OVER(PARTITION BY region ORDER BY month) AS prev
 FROM skeleton
)
SELECT region,month,net_cents,prev,
 CASE WHEN prev IS NULL OR prev=0 THEN NULL ELSE (net_cents-prev)*1.0/prev END AS mom
FROM lagged ORDER BY region,month
