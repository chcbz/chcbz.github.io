#!/usr/bin/env python3
"""人工教学数据；标准库SQLite；不是生产压测或客户数据。"""
import csv
import json
import sqlite3
from pathlib import Path

OUT = Path(__file__).resolve().parent / 'output'
OUT.mkdir(exist_ok=True)
ORDERS = [
    ('o1', 'east', '2026-01-05', 10000, 'paid'),
    ('o2', 'east', '2026-01-10', 20000, 'paid'),
    ('o3', 'east', '2026-03-05', 30000, 'paid'),
    ('o4', 'west', '2026-01-06', 5000, 'paid'),
    ('o5', 'west', '2026-02-06', 10000, 'paid'),
    ('o6', 'east', '2026-02-09', 99900, 'cancelled'),
]
REFUNDS = [('r1', 'o1', 1000), ('r2', 'o1', 2000), ('r3', 'o2', 2000)]
MONTHLY_SQL = """
WITH months(month) AS (VALUES ('2026-01'),('2026-02'),('2026-03')),
regions(region) AS (VALUES ('east'),('west')),
r AS (SELECT order_id, SUM(refund_cents) AS refund FROM refunds GROUP BY order_id),
a AS (
 SELECT o.region, substr(o.order_date,1,7) AS month,
        SUM(o.amount_cents-COALESCE(r.refund,0)) AS net_cents
 FROM orders o LEFT JOIN r ON o.order_id=r.order_id
 WHERE o.status='paid' AND o.order_date>='2026-01-01' AND o.order_date<'2026-04-01'
 GROUP BY o.region, substr(o.order_date,1,7)
),
skeleton AS (
 SELECT regions.region,months.month,COALESCE(a.net_cents,0) AS net_cents
 FROM regions CROSS JOIN months
 LEFT JOIN a ON a.region=regions.region AND a.month=months.month
), lagged AS (
 SELECT *, LAG(net_cents) OVER(PARTITION BY region ORDER BY month) AS prev
 FROM skeleton
)
SELECT region,month,net_cents,prev,
 CASE WHEN prev IS NULL OR prev=0 THEN NULL ELSE (net_cents-prev)*1.0/prev END AS mom
FROM lagged ORDER BY region,month
"""

def main():
    assert sqlite3.sqlite_version_info >= (3,25,0), 'SQLite >=3.25 required'
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    db.executescript('''
    PRAGMA foreign_keys=ON;
    CREATE TABLE orders(order_id TEXT PRIMARY KEY,region TEXT NOT NULL,
      order_date TEXT NOT NULL,amount_cents INTEGER NOT NULL,status TEXT NOT NULL);
    CREATE TABLE refunds(refund_id TEXT PRIMARY KEY,order_id TEXT NOT NULL,
      refund_cents INTEGER NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(order_id));
    ''')
    db.executemany('INSERT INTO orders VALUES(?,?,?,?,?)', ORDERS)
    db.executemany('INSERT INTO refunds VALUES(?,?,?)', REFUNDS)
    rows = [dict(r) for r in db.execute(MONTHLY_SQL)]
    assert [r['net_cents'] for r in rows] == [25000,0,30000,5000,10000,0]
    assert rows[0]['mom'] is None
    assert rows[1]['mom'] == -1.0
    assert rows[2]['mom'] is None
    assert rows[4]['mom'] == 1.0
    assert rows[5]['mom'] == -1.0
    assert sum(r['net_cents'] for r in rows) == 70000
    bad = db.execute("""SELECT SUM(o.amount_cents-r.refund_cents) FROM orders o
       JOIN refunds r ON o.order_id=r.order_id WHERE o.order_id='o1'""").fetchone()[0]
    good = db.execute("""SELECT amount_cents-(SELECT SUM(refund_cents) FROM refunds
       WHERE order_id='o1') FROM orders WHERE order_id='o1'""").fetchone()[0]
    assert (bad, good) == (17000,7000)
    db.executescript('''
    CREATE TABLE scores(id INTEGER PRIMARY KEY,region TEXT,amount INTEGER);
    INSERT INTO scores VALUES(1,'east',100),(2,'east',90),(3,'east',90),(4,'east',80),(5,'east',70);
    CREATE TABLE events(k TEXT,updated_at TEXT,seq INTEGER,value TEXT);
    INSERT INTO events VALUES('a','2026-01-01',1,'old'),('a','2026-01-02',2,'new'),
       ('a','2026-01-02',3,'latest');
    CREATE TABLE target(k TEXT PRIMARY KEY,version INTEGER,value TEXT);
    CREATE TABLE dim_region(customer TEXT,region TEXT,valid_from TEXT,valid_to TEXT);
    INSERT INTO dim_region VALUES('c1','east','2026-01-01','2026-02-01'),
        ('c1','west','2026-02-01','9999-12-31');
    ''')
    ranked = [dict(r) for r in db.execute('''SELECT *,ROW_NUMBER() OVER(
       PARTITION BY region ORDER BY amount DESC,id) AS rn,
       DENSE_RANK() OVER(PARTITION BY region ORDER BY amount DESC) AS dr FROM scores''')]
    assert len([r for r in ranked if r['rn']<=3]) == 3
    assert len([r for r in ranked if r['dr']<=3]) == 4
    latest = db.execute('''WITH x AS (SELECT *,ROW_NUMBER() OVER(
       PARTITION BY k ORDER BY updated_at DESC,seq DESC) rn FROM events)
       SELECT value FROM x WHERE rn=1''').fetchone()[0]
    assert latest == 'latest'
    upsert = '''INSERT INTO target VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET
       version=excluded.version,value=excluded.value WHERE excluded.version>target.version'''
    for event in [('a',3,'v3'),('a',2,'v2'),('a',3,'v3')]:
        db.execute(upsert,event)
    assert tuple(db.execute('SELECT * FROM target').fetchone()) == ('a',3,'v3')
    boundary = db.execute('''SELECT region FROM dim_region WHERE customer='c1'
       AND valid_from<=? AND ?<valid_to''', ('2026-02-01','2026-02-01')).fetchall()
    assert [r[0] for r in boundary] == ['west']
    for name, header, values in [
        ('orders.csv',['order_id','region','order_date','amount_cents','status'],ORDERS),
        ('refunds.csv',['refund_id','order_id','refund_cents'],REFUNDS)]:
        with (OUT/name).open('w',encoding='utf-8',newline='') as f:
            w=csv.writer(f); w.writerow(header); w.writerows(values)
    (OUT/'monthly_sql.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'monthly_query.sql').write_text(MONTHLY_SQL,encoding='utf-8')
    print('SQL PASS: 14 assertions; net total=700.00; bad JOIN=170.00 vs correct=70.00')
    print(json.dumps(rows,ensure_ascii=False,indent=2))
    db.close()

if __name__ == '__main__':
    main()
